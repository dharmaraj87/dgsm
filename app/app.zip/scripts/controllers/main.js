'use strict';

/**
 * @ngdoc function
 * @name testProjApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the testProjApp
 */
//var app = angular.module('testProjApp',[])
angular.module('testProjApp')
  .controller('MainCtrl', function ($scope, $rootScope, serviceData, $uibModal, $log) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
    $scope.items = {};
	$scope.tShirts = ['T1','T2','T3','T4'];
   	$scope.animationsEnabled = true
	$rootScope.tShirtsInfo = serviceData.shopData();
	$scope.sum = function(index, qty) {
       $scope.subTotal = 0.00;

      var i = 0;
      for(i =0; i < $rootScope.tShirtsInfo.productsInCart.length; i++) {
         $scope.subTotal += $rootScope.tShirtsInfo.productsInCart[i].p_quantity * $rootScope.tShirtsInfo.productsInCart[i].p_price
      }
      $scope.subTotal = parseFloat(Math.round($scope.subTotal * 100) / 100).toFixed(2)
      $scope.total = $scope.subTotal - 7
   }
   $scope.sum()
   $rootScope.qtyUpdate = function(index, qty) {
      $scope.subTotal = 0.00;
      var j = 0;
      for(j = 0; j < $rootScope.tShirtsInfo.productsInCart.length; j++) {
         if(index != j) {
            $scope.subTotal += $rootScope.tShirtsInfo.productsInCart[j].p_quantity * $rootScope.tShirtsInfo.productsInCart[j].p_price
         }
         else {
            $scope.subTotal += qty * $rootScope.tShirtsInfo.productsInCart[index].p_price
         }
      }
      $scope.subTotal = parseFloat(Math.round($scope.subTotal * 100) / 100).toFixed(2)
      $scope.total = $scope.subTotal - 7
   }

   $scope.edit = function(data, img) {
      var modalInstance = $uibModal.open({
         backdrop: 'static',
         animation: $scope.animationsEnabled,
         templateUrl: '../../views/edit.html',
         controller: 'shopInstanceCtrl',
         resolve: {
           items: function () {
             return $scope.items
            },
            getData: function() {
            	return data
            },
            getImages: function() {
            	return img
            }
         }
       });

       modalInstance.result.then(function (selectedItem) {

         $scope.selected = selectedItem;

       }, 

       function () {

         $log.info('Modal dismissed at: ' + new Date());

       });
   }
   
  });


angular.module('testProjApp').controller('shopInstanceCtrl', function ($scope, $uibModalInstance, getData, getImages, serviceData, items, $rootScope) {
   $scope.items = items;
   $scope.qtyNumber = [1,2,3,4,5,6,7,8,9,10]
   $scope.qtyNo = $scope.qtyNumber[0]
   $scope.getImages = getImages;
   $scope.getData = getData;
   $scope.size = $scope.getData.p_available_options.sizes[0]

   $scope.submit = function(obj, qtyNo) {
   	var i = 0;
   	for(i = 0; i < $rootScope.tShirtsInfo.productsInCart.length; i++) {
   		if($rootScope.tShirtsInfo.productsInCart[i].p_id == obj.p_id) {
   			$rootScope.tShirtsInfo.productsInCart[i].p_available_options.sizes =  obj.p_available_options.sizes
   			$rootScope.tShirtsInfo.productsInCart[i].p_quantity = qtyNo
   			$rootScope.qtyUpdate(i,qtyNo)
   			$uibModalInstance.close($scope.selected.item);
   		}
   	}
   		
   }
   console.log($scope.getData)
   $scope.selected = {
       item: $scope.items[0]
   };
   $scope.cancel = function () {
       $uibModalInstance.dismiss('cancel');
   };
});